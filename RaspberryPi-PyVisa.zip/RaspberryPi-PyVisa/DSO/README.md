This folder contains scripts to control the RIGOL DSO
